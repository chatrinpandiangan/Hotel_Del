<?php

class MonkeyPatch extends Kenjis\MonkeyPatch\MonkeyPatch
{
}
